// Netlify Function  ->  POST /api/notify
// Sends the ExamLab feedback-invitation email through Resend.
// SECURITY: the Resend API key is read from the RESEND_API_KEY environment variable
// (Netlify > Project configuration > Environment variables). Never paste it into any file.
//
// Environment variables
//   RESEND_API_KEY  (required)  your Resend API key (keep "Functions" ticked in its scopes)
//   RESEND_FROM     (optional)  e.g. "ExamLab <feedback@yourdomain.com>"  (needs a domain verified in Resend)
//                               default: "ExamLab <onboarding@resend.dev>"  (Resend sandbox: delivers ONLY to your own Resend account email)
//   ALLOWED_ORIGIN  (optional)  e.g. "https://your-site.netlify.app"  (only this site may call the endpoint)
//   SEND_AT         (optional)  ISO 8601 time, e.g. "2026-01-30T18:00:00Z"  (Resend sends the email then instead of immediately)

const FORM_URL = "https://examlabfeedbackform.edgeone.dev";
const SUBJECT = "Share your experience at your exam centre | ExamLab";
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const CENTRE_RE = /^C0(0[1-9]|[12][0-9]|3[0-9]|40)$/;

const json = (obj, status = 200) => new Response(JSON.stringify(obj), {
  status,
  headers: { "Content-Type": "application/json", "Cache-Control": "no-store" }
});

const buildHtml = (link) => `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="color-scheme" content="light">
<title>Share your experience at your exam centre | ExamLab</title>
</head>
<body style="margin:0;padding:0;background-color:#eef1f6;">
<!-- Subject: Share your experience at your exam centre | ExamLab -->
<div style="display:none;max-height:0;overflow:hidden;opacity:0;color:#eef1f6;font-size:1px;line-height:1px;">Your feedback helps us improve the examination experience for future JEE aspirants.</div>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:#eef1f6;">
<tr><td align="center" style="padding:24px 12px;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="max-width:600px;background-color:#ffffff;border-radius:16px;overflow:hidden;font-family:'Segoe UI',Helvetica,Arial,sans-serif;color:#1b2433;">

<tr><td style="background-color:#254bdb;padding:20px 28px;font-size:22px;font-weight:800;color:#ffffff;letter-spacing:-0.01em;">ExamLab</td></tr>

<tr><td style="padding:28px 28px 8px 28px;">
<h1 style="margin:0 0 14px 0;font-size:24px;line-height:1.25;color:#1b2433;">How was your exam?</h1>
<p style="margin:0 0 14px 0;font-size:16px;line-height:1.6;">Hello,</p>
<p style="margin:0 0 14px 0;font-size:16px;line-height:1.6;">Thank you for using ExamLab. We hope ExamLab helped you understand your centre better and prepare for your exam with greater confidence, and we hope your JEE exam went well.</p>
<p style="margin:0 0 14px 0;font-size:16px;line-height:1.6;">When you checked your centre, you asked us to notify you after your exam. This is that feedback invitation.</p>
<p style="margin:0 0 20px 0;font-size:16px;line-height:1.6;"><strong>Please use the button given below to submit your feedback about what happened at your examination centre during the exam.</strong></p>
</td></tr>

<tr><td align="center" style="padding:0 28px 12px 28px;">
<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin:0 auto;">
<tr><td align="center" bgcolor="#254bdb" style="border-radius:12px;background-color:#254bdb;">
<a href="${link}" target="_blank" style="display:inline-block;padding:16px 34px;font-family:'Segoe UI',Helvetica,Arial,sans-serif;font-size:17px;font-weight:700;color:#ffffff;text-decoration:none;border-radius:12px;">Submit your feedback</a>
</td></tr>
</table>
</td></tr>

<tr><td style="padding:4px 28px 20px 28px;text-align:center;font-size:13px;line-height:1.5;color:#5d6b80;">
If the button does not work, copy and paste this link into your browser:<br>
<a href="${link}" target="_blank" style="color:#254bdb;word-break:break-all;">${link}</a>
</td></tr>

<tr><td style="padding:8px 28px 4px 28px;">
<h2 style="margin:0 0 10px 0;font-size:18px;color:#1b2433;">Before You Submit Your Feedback</h2>
<p style="margin:0 0 10px 0;font-size:15px;line-height:1.6;">The feedback form has five short steps:</p>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:#f4f6fa;border-radius:12px;">
<tr><td style="padding:14px 18px;font-size:15px;line-height:1.7;">
<strong>1.</strong> Confirm that you appeared for the examination at your centre.<br>
<strong>2.</strong> Read how we use your information (Privacy &amp; Data Use).<br>
<strong>3.</strong> Enter your full name, 12-digit application number and 10-digit roll number. Uploading your admit card is optional.<br>
<strong>4.</strong> Tell us whether you faced any problem (Mouse/Input, Display, Network, Timer/System, Restart/System or Other) and write how your exam went.<br>
<strong>5.</strong> Submit, and you are done.
</td></tr>
</table>
</td></tr>

<tr><td style="padding:16px 28px 4px 28px;">
<h2 style="margin:0 0 10px 0;font-size:18px;color:#1b2433;">Please keep ready</h2>
<p style="margin:0;font-size:15px;line-height:1.6;">Your centre code (for example, C039), your full name, your 12-digit application number and your 10-digit roll number.</p>
</td></tr>

<tr><td style="padding:20px 28px 4px 28px;">
<h2 style="margin:0 0 10px 0;font-size:18px;color:#1b2433;">Your privacy</h2>
<p style="margin:0 0 8px 0;font-size:15px;line-height:1.6;">Providing feedback is voluntary. We do not use your information for advertising or unrelated purposes, and we do not publicly display your personal information alongside your feedback. We will only use your email to send you this post-exam feedback invitation.</p>
</td></tr>

<tr><td style="padding:20px 28px 28px 28px;">
<p style="margin:0 0 14px 0;font-size:16px;line-height:1.6;">Share your experience at the centre and help us make the examination experience better for future JEE aspirants. <strong>Your feedback helps us improve the examination experience for future JEE aspirants.</strong></p>
<p style="margin:0 0 4px 0;font-size:16px;line-height:1.6;">Thank you for sharing your experience.</p>
<p style="margin:14px 0 0 0;font-size:16px;line-height:1.6;">Warm regards,<br><strong>The ExamLab Team</strong></p>
</td></tr>

<tr><td style="background-color:#f4f6fa;padding:16px 28px;font-size:12px;line-height:1.6;color:#5d6b80;">
You are receiving this email because you asked to be notified after your exam. If you did not request this, you can safely ignore it.
</td></tr>

</table>
</td></tr>
</table>
</body>
</html>
`;

const buildText = (link) => `Hello,

Thank you for using ExamLab. We hope ExamLab helped you understand your centre better and prepare for your exam with greater confidence, and we hope your JEE exam went well.

When you checked your centre, you asked us to notify you after your exam. This is that feedback invitation.

Please use the button given below to submit your feedback about what happened at your examination centre during the exam.

>> Submit your feedback: ${link}

BEFORE YOU SUBMIT YOUR FEEDBACK
The feedback form has five short steps:
1. Confirm that you appeared for the examination at your centre.
2. Read how we use your information (Privacy & Data Use).
3. Enter your full name, 12-digit application number and 10-digit roll number. Uploading your admit card is optional.
4. Tell us whether you faced any problem (Mouse/Input, Display, Network, Timer/System, Restart/System or Other) and write how your exam went.
5. Submit, and you are done.

PLEASE KEEP READY
Your centre code (for example, C039), your full name, your 12-digit application number and your 10-digit roll number.

YOUR PRIVACY
Providing feedback is voluntary. We do not use your information for advertising or unrelated purposes, and we do not publicly display your personal information alongside your feedback. We will only use your email to send you this post-exam feedback invitation.

Share your experience at the centre and help us make the examination experience better for future JEE aspirants. Your feedback helps us improve the examination experience for future JEE aspirants.

Thank you for sharing your experience.

Warm regards,
The ExamLab Team

--
You are receiving this email because you asked to be notified after your exam. If you did not request this, you can safely ignore it.
`;

export default async (req) => {
  // Open /api/notify in a browser to check the setup (shows no secrets).
  if (req.method === "GET") {
    return json({
      ok: true,
      keyConfigured: Boolean(Netlify.env.get("RESEND_API_KEY")),
      sender: Netlify.env.get("RESEND_FROM") ? "your own domain (RESEND_FROM is set)" : "Resend test sender (delivers only to your own Resend account email)"
    });
  }
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  const apiKey = Netlify.env.get("RESEND_API_KEY");
  if (!apiKey) return json({ error: "Email service is not configured." }, 500);

  const allowed = Netlify.env.get("ALLOWED_ORIGIN");
  if (allowed) {
    if ((req.headers.get("Origin") || "") !== allowed) return json({ error: "Forbidden" }, 403);
  }

  let body;
  try { body = await req.json(); } catch (e) { return json({ error: "Invalid request." }, 400); }

  const email = String(body.email || "").trim().toLowerCase();
  const centre = String(body.centre || "").trim().toUpperCase();
  if (email.length > 254 || !EMAIL_RE.test(email)) return json({ error: "Please enter a valid email address." }, 400);

  const link = CENTRE_RE.test(centre) ? FORM_URL + "/?centre=" + centre : FORM_URL;

  const payload = {
    from: Netlify.env.get("RESEND_FROM") || "ExamLab <onboarding@resend.dev>",
    to: [email],
    subject: SUBJECT,
    html: buildHtml(link),
    text: buildText(link)
  };
  const sendAt = Netlify.env.get("SEND_AT");
  if (sendAt) payload.scheduled_at = sendAt;

  let res;
  try {
    res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: "Bearer " + apiKey, "Content-Type": "application/json", "User-Agent": "examlab-notify/1.0" }, // Resend rejects requests without a User-Agent (error 1010)
      body: JSON.stringify(payload)
    });
  } catch (e) {
    return json({ error: "Could not reach the email service." }, 502);
  }
  if (!res.ok) {
    let detail = "";
    try { const j = await res.json(); detail = (j.name ? j.name + ": " : "") + (j.message || ""); } catch (e) {}
    detail = detail.replace(/[^\s()]+@[^\s()]+/g, "[email]").slice(0, 300); // never expose email addresses
    console.log("Resend error", res.status, detail);
    return json({ error: "Could not send the email.", detail }, 502);
  }
  return json({ ok: true });
};

export const config = { path: "/api/notify", method: ["GET", "POST"] };
